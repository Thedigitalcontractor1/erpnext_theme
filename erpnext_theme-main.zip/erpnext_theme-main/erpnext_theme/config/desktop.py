from frappe import _

def get_data():
	return [
		{
			"module_name": "Sky Hook ERP Theme",
			"color": "grey",
			"icon": "octicon octicon-file-directory",
			"type": "module",
			"label": _("Sky Hook ERP Theme")
		}
	]
