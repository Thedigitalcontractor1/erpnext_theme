## Skyhook ERP Theme V14

Skyhook ERP Theme for ERPNext / Frappe

### To install this theme,

bench get-app https://github.com/SkyHook-ERP/erpnext_theme.git

bench --site (sitename) install-app erpnext_theme

bench clear-cache


### To uninstall this theme

bench --site (sitename) uninstall-app erpnext_theme

#### License

AGPL
